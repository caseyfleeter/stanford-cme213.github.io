mpirun -mca btl ^openib -n 8 ./mpi_pi_send
