#include <cassert>
#include <cmath>
#include <cstdio>
#include <unistd.h>

#include <chrono>
#include <thread>
#include <vector>

using namespace std;
using namespace std::chrono;

void ProcessOpt(int argc, char **argv, int *size, int *n_thread, bool *debug)
{
    int c;
    extern char *optarg;
    extern int optopt;
    *size = 64;
    *n_thread = 1;
    *debug = false;

    while ((c = getopt(argc, argv, "n:p:gh")) != -1)
        switch (c)
        {
        case 'n':
            *size = atoi(optarg);
            break;

        case 'p':
            *n_thread = atoi(optarg);
            break;

        case 'g':
            *debug = true;
            break;

        case 'h':
            printf(
                "Options:\n-n SIZE\t\tMatrix size\n-p NTHREAD\tNumber of threads\n");
            printf("-g\t\tCheck error in computation\n");
            exit(2);

        case '?':
            fprintf(stderr, "Unrecognized option: -%c\n", optopt);
            exit(2);
        }
}

/* A(i,j) */
float MatA(int i, int j)
{
    if (j % 2 == 0)
    {
        return i % 16;
    }
    else
    {
        return -(i % 16);
    }
}

/* B(i,j) */
float MatB(int i, int j)
{
    if ((i + j) % 2)
    {
        return i;
    }

    return j;
}

void InitializeMatrices(int size, vector<float> &mat_a, vector<float> &mat_b)
{
    int i, j;

    for (i = 0; i < size; ++i)
        for (j = 0; j < size; ++j)
        {
            mat_a[i * size + j] = MatA(i, j);
            mat_b[i * size + j] = MatB(i, j);
        }
}

void MatrixMult(int size, int row_start, int row_end, vector<float> &mat_c)
{
    printf("Processing row %3d to %3d\n", row_start, row_end - 1);

    for (int i = row_start; i < row_end; ++i)
        for (int j = 0; j < size; ++j)
        {
            float c_ij = 0.;

            for (int k = 0; k < size; ++k)
            {
                c_ij += MatA(i, k) * MatB(k, j);
            }

            mat_c[i * size + j] = c_ij;
        }
}

int main(int argc, char **argv)
{
    int size, n_thread; /* Number of threads to use */
    bool debug;

    /* Command line options */
    ProcessOpt(argc, argv, &size, &n_thread, &debug);
    assert(n_thread >= 1 && size >= 1);
    printf("Size of matrix = %d\n", size);
    printf("Number of threads to create = %d\n", n_thread);

    /* Output matrix C */
    vector<float> mat_c(size * size);

    /* Number of rows each thread will process */
    int nrow_per_thread = (size + n_thread - 1) / n_thread;

    vector<thread> threads; // thread pool

    /* Begin */
    high_resolution_clock::time_point time_begin = high_resolution_clock::now();

    /* Create all threads and do the computation */
    for (int i = 0; i < n_thread; ++i)
        threads.push_back(thread(MatrixMult, size,
                                 i * nrow_per_thread,                  /* row_start */
                                 min(size, (i + 1) * nrow_per_thread), /* row_end */
                                 ref(mat_c)));

    /* Wait for threads to be done */
    for (int i = 0; i < n_thread; ++i)
        threads[i].join();

    /* End */
    high_resolution_clock::time_point time_end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(time_end - time_begin).count();
    printf("Elapsed time [millisec]: %lld\n", duration);

    if (debug) /* -g */
    {
        /* Debug: check result */
        vector<float> mat_d(size * size);

        for (int i = 0; i < size; ++i)
            for (int j = 0; j < size; ++j)
            {
                float d_ij = 0.;

                for (int k = 0; k < size; ++k)
                {
                    d_ij += MatA(i, k) * MatB(k, j);
                }
                assert(d_ij == mat_c[i * size + j]);
            }

        printf("PASS\n");
    }

    return 0;
}
