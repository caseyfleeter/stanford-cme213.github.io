#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <stdbool.h>
#include <getopt.h>
#include <math.h>

#include <pthread.h>

#define min(a,b) (a < b ? a : b)
#define max(a,b) (a > b ? a : b)

/* Return 1 if the difference is negative, otherwise 0.  */
int TimeSubtract(struct timeval* result, struct timeval* t2,
                 struct timeval* t1) {
    long int micro = 1000000;
    long int diff = (t2->tv_usec + micro * t2->tv_sec)
                    - (t1->tv_usec + micro * t1->tv_sec);
    result->tv_sec = diff / micro;
    result->tv_usec = diff % micro;

    return (diff < 0);
}

void TimePrint(struct timeval* tv) {
    char buffer[26];
    int millisec;
    struct tm* tv_info;

    millisec = tv->tv_usec / 1000.0;

    /* Round to nearest millisec */
    if (millisec>=1000) { /* Allow for rounding up to nearest second */
        millisec -=1000;
        tv->tv_sec++;
    }

    tv_info = localtime(&tv->tv_sec);

    strftime(buffer, 26, "%Y:%m:%d %H:%M:%S", tv_info);
    printf("%s.%03d\n", buffer, millisec);
}

void ProcessOpt(int argc, char** argv, int* size, int* n_thread, bool* debug) {
    int c;
    extern char *optarg;
    extern int optopt;
    *size = 64;
    *n_thread = 1;
    *debug = false;

    while((c = getopt(argc, argv, "n:p:gh")) != -1)
        switch(c) {
        case 'n':
            *size = atoi(optarg);
            break;

        case 'p':
            *n_thread = atoi(optarg);
            break;

        case 'g':
            *debug = true;
            break;

        case 'h':
            printf(
                "Options:\n-n SIZE\t\tMatrix size\n-p NTHREAD\tNumber of threads\n");
            printf("-g\t\tCheck error in computation\n");
            exit(2);

        case '?':
            fprintf(stderr,"Unrecognized option: -%c\n", optopt);
            exit(2);
        }
}

/* A(i,j) */
float MatA(int i, int j) {
    if(j%2 == 0) {
        return i%16;
    } else {
        return -(i%16);
    }
}

/* B(i,j) */
float MatB(int i, int j) {
    if((i+j)%2) {
        return i;
    }

    return j;
}

void InitializeMatrices(int size, float* mat_a, float* mat_b) {
    int i, j;

    for(i = 0; i < size; ++i)
        for(j = 0; j < size; ++j) {
            mat_a[i * size + j] = MatA(i, j);
            mat_b[i * size + j] = MatB(i, j);
        }
}

typedef struct {
    int size;
    int row_start, row_end;
    float* mat_c;
} MatrixType;

void* MatrixMult(void* w) {
    MatrixType* work;
    int size;
    float* mat_c, c_ij;

    int i, j, k;

    work = (MatrixType*) w;
    mat_c = work->mat_c;
    size = work->size;

    printf("Processing row %3d to %3d\n", work->row_start, work->row_end - 1);

    for(i = work->row_start; i < work->row_end; ++i)
        for(j = 0; j < size; ++j) {
            c_ij = 0.;

            for(k = 0; k < size; ++k) {
                c_ij += MatA(i, k) * MatB(k, j);
            }

            mat_c[i * size + j] = c_ij;
        }

    pthread_exit(NULL);
}

int main(int argc, char** argv) {
    int size;
    float* mat_c, *mat_d, d_ij;
    int n_thread; /* Number of threads to use */
    bool debug;
    MatrixType* work;  /* Thread data */
    pthread_t* thread;

    struct timeval time_begin, time_end, time_diff; /* For timing */
    int i, j, k, nrow_per_thread;
    float err;

    /* Command line options */
    ProcessOpt(argc, argv, &size, &n_thread, &debug);
    assert(n_thread >= 1);
    assert(size >= 1);
    printf("Size of matrix = %d\n", size);
    printf("Number of threads to create = %d\n", n_thread);

    thread = (pthread_t*) malloc(sizeof(pthread_t) * n_thread);
    work = (MatrixType*) malloc(sizeof(MatrixType) * n_thread);

    /* Initialize output matrix C */
    mat_c = (float*) malloc(sizeof(float) * size * size);

    /* Number of rows each thread will process */
    nrow_per_thread = (size + n_thread - 1) / n_thread;

    /* Begin */
    gettimeofday(&time_begin, NULL);
    TimePrint(&time_begin);

    /* Create all threads and do the computation */
    for(i = 0; i < n_thread; ++i) {
        work[i].size = size;
        work[i].mat_c = mat_c;
        work[i].row_start = i * nrow_per_thread;
        work[i].row_end = min(size, (i + 1) * nrow_per_thread);
        pthread_create(thread + i, NULL, MatrixMult, (void*)(work + i));
    }

    /* Wait for threads to be done */
    for(i = 0; i < n_thread; ++i) {
        pthread_join(thread[i], NULL);
    }

    /* End */
    gettimeofday(&time_end, NULL);
    TimePrint(&time_end);

    /* Elapsed */
    TimeSubtract(&time_diff, &time_end, &time_begin);
    printf("Elapsed time [sec]: %ld.%06d\n", time_diff.tv_sec, time_diff.tv_usec);

    if(debug) {
        /* Debug: check result */
        mat_d = (float*) malloc(sizeof(float) * size * size);

        for(i = 0; i < size; ++i)
            for(j = 0; j < size; ++j) {
                d_ij = 0.;

                for(k = 0; k < size; ++k) {
                    d_ij += MatA(i, k) * MatB(k, j);
                }

                mat_d[i * size + j] = d_ij;
            }

        err = 0.;

        for(i = 0; i < size * size; ++i) {
            err = max(err, fabs(mat_d[i] - mat_c[i]));
            assert(mat_d[i] == mat_c[i]);
        }

        printf("Error = %g\n", err);
        free(mat_d);
    }

    free(mat_c);
    free(work);
    free(thread);

    return 0;
}
