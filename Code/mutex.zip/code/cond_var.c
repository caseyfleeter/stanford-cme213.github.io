#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define NUMTASKS 4
#define NUMTHREADS 2 /* Should divide NUMTASKS */

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

typedef struct TaskList
{
    struct TaskList *next;
    char *work_to_do;
} TaskList;

TaskList *global_task_list; /* Head of task list */

TaskList *InsertNewOrder(const char *order, TaskList *prev)
{
    TaskList *new_task;
    new_task = (TaskList *)malloc(sizeof(TaskList));
    new_task->next = NULL;
    new_task->work_to_do = (char *)malloc(sizeof(char) * 80);
    strncpy(new_task->work_to_do, order, 80); /* (dest, src, size) */

    if (prev != NULL)
    {
        prev->next = new_task;
    }

    puts(new_task->work_to_do); /* Write to stdout the content of the task */

    return new_task;
}

#define MILLISEC 1000000

void RandomWait()
{
    struct timespec req, rem;
    req.tv_sec = 0;
    req.tv_nsec = (1 + rand() % 10) * MILLISEC; /* Wait time in milliseconds*/
    nanosleep(&req, &rem);
}

void *PizzaDeliveryPronto(void *tid)
{
    int tasks_to_do = NUMTASKS / NUMTHREADS;
    long thread_id = (long)tid;
    TaskList *my_task;

    while (tasks_to_do--)
    {
        RandomWait();
        pthread_mutex_lock(&mutex);
        while (global_task_list == NULL)
        {
            printf("Consumer thread %ld: waiting for next task\n", thread_id);
            pthread_cond_wait(&cond, &mutex);
            /* Mutex unlocks while waiting. 
               Locks when returning from pthread_cond_wait(). */
        }
        my_task = global_task_list; /* Task that thread is going to process */
        global_task_list = global_task_list->next; /* Next task */
        pthread_mutex_unlock(&mutex);

        printf("Consumer thread %ld: grabbed task %s\n", thread_id,
               my_task->work_to_do);
        printf("Consumer thread %ld: mutex unlocked\n", thread_id);

        /* At this point, the thread delivers the pizza. */
        /* The mutex is unlocked so that other threads can work. */
        free(my_task->work_to_do);
        free(my_task);
    }

    printf("Consumer thread %ld: all done\n\n", thread_id);

    return NULL;
}

int main(int argc, char **argv)
{
    pthread_t thread[NUMTHREADS];
    int n_orders = NUMTASKS;
    long i;
    TaskList *curr_task = NULL;
    char order[80];

    printf("Using %d threads to process %d tasks\n", NUMTHREADS, NUMTASKS);

    global_task_list = NULL;

    for (i = 0; i < NUMTHREADS; ++i)
    {
        pthread_create(&thread[i], NULL, PizzaDeliveryPronto, (void *)i);
    }

    /* The producer loop */
    printf("Producer thread: waiting for orders; standing by the phone\n\n");

    while (n_orders--)
    {
        RandomWait();

        /* Received a call. */
        printf("Producer thread: received a phone call\n");
        snprintf(order, 80, "Pizza delivery to customer ID %d", rand() % 100);
        pthread_mutex_lock(&mutex); /* Protect shared data. */
        printf("Producer thread: locked mutex\n");

        if (global_task_list == NULL)
        { /* Queue is empty */
            curr_task = InsertNewOrder(order, NULL);
            global_task_list = curr_task; /* Head of queue */
        }
        else
        {
            curr_task = InsertNewOrder(order, curr_task);
        }

        pthread_cond_signal(&cond); /* Wake up a consumer. */

        pthread_mutex_unlock(&mutex);
        printf("Producer thread: cond_signal and mutex unlocked\n");
    }

    printf("Producer thread: waiting for the consumer threads\n\n");

    for (i = 0; i < NUMTHREADS; ++i)
    {
        pthread_join(thread[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
    printf("That was a pretty long day of work! Goodbye CME 213.\n");

    return 0;
}
