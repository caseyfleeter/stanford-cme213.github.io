#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <getopt.h>
#include <time.h>
#include <sys/time.h>

#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct TaskList
{
    struct TaskList *next;
    char *work_to_do;
} TaskList;

TaskList *global_task_list; /* Points to the next task to perform by threads */

TaskList *InsertNewOrder(const char *order, TaskList *prev)
{
    TaskList *new_task;
    new_task = (TaskList *)malloc(sizeof(TaskList));
    new_task->next = NULL;
    new_task->work_to_do = (char *)malloc(sizeof(char) * 80);
    strncpy(new_task->work_to_do, order, 80); /* (dest, src, size) */

    if (prev != NULL)
    {
        prev->next = new_task;
    }

    puts(new_task->work_to_do); /* Write to stdout the content of the task */

    return new_task;
}

#define MILLISEC 1000000

void Wait()
{
    struct timespec req, rem;
    req.tv_sec = 0;
    req.tv_nsec = MILLISEC;
    /* wait time in nanoseconds*/
    nanosleep(&req, &rem);
}

void Delivery()
{
    // Pretend I am really busy doing something here
    // Nice job, isn't it? The pay is good too.
}

void *PizzaDeliveryPronto(void *tid)
{
    long thread_id = (long)tid;
    TaskList *my_task;

    while (1)
    {
        pthread_mutex_lock(&mutex);

        if (global_task_list != NULL)
        {
            my_task = global_task_list;                /* Pop a task */
            Wait();   /* This causes several threads to use the same task pointer */
            global_task_list = global_task_list->next; /* Move forward by one task */
            pthread_mutex_unlock(&mutex);

            /* At this point, the thread delivers the pizza. */
            /* The mutex is unlocked so that other threads can work. */
            printf("Thread %ld: %s\n", thread_id, my_task->work_to_do);
            Delivery();

            /* Work is done */
            free(my_task->work_to_do); /* Free task data */
            free(my_task);             /* Free task itself */
        }
        else
        {
            pthread_mutex_unlock(&mutex); /* Don't forget to unlock the mutex */
            pthread_exit(NULL);
        }
    }
}

#define NTHREADS 4
#define NORDERS 16

int main(int argc, char **argv)
{
    TaskList *curr_task; /* Points to the last task that was inserted */
    long i;

    char order[80];

    pthread_t thread[NTHREADS];

    printf("Pizza store jobs:\n");

    strncpy(order, "Open the store", 80);
    curr_task = InsertNewOrder(order, NULL);

    global_task_list = curr_task;

    /* Insert some tasks */
    for (i = 0; i < NORDERS; ++i)
    {
        /* Got a phone call for pizza delivery. */
        snprintf(order, 80, "Pizza delivery to customer no. %d", rand() % 100 + 1);
        curr_task = InsertNewOrder(order, curr_task);
    }

    strncpy(order, "Close the store", 80);
    curr_task = InsertNewOrder(order, curr_task);

    printf("\n");

    /* Have threads consume tasks */
    for (i = 0; i < NTHREADS; ++i)
    {
        pthread_create(thread + i, NULL, PizzaDeliveryPronto, (void *)i);
    }

    for (i = 0; i < NTHREADS; ++i)
    {
        pthread_join(thread[i], NULL);
    }

    pthread_mutex_destroy(&mutex);

    printf("\nDone. Goodbye CME213.\n");

    return 0;
}
