import numpy as np


def quicksort(A, l, u):
    if l < u-1:
        x = A[l]
        s = l
        for i in range(l+1, u):
            if A[i] <= x:
                s = s+1
                A[s], A[i] = A[i], A[s]
        A[s], A[l] = A[l], A[s]
        quicksort(A, l, s)
        quicksort(A, s+1, u)


A = np.array([4, 6, 1, 5, 7, 3, 8, 2])
n = 16
A = np.random.random_integers(0, n**2, n)

l = 0
u = A.size

quicksort(A, l, u)

for i in range(A.size-1):
    assert(A[i] <= A[i+1])
